"use client";

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ChatMessage {
  role: "bot" | "user";
  text: string;
}

interface PublicProject {
  id: string;
  name: string;
  district: string;
  state: string;
  stage: string;
}

const STAGE_LABELS: Record<string, string> = {
  NOTIFIED: "notified — the government has formally announced this project",
  STATE_APPROVED: "approved at the state level",
  CENTRAL_APPROVED: "approved at the central government level",
  DECLARED: "declared — the acquisition is now legally final",
  AWARDED: "awarded — compensation amounts have been decided",
  RR_IN_PROGRESS: "in the rehabilitation & resettlement stage",
  POSSESSION: "at the possession stage — the government is taking formal possession of the land",
  RR_COMPLETE: "complete — rehabilitation, resettlement, and infrastructure are all finished",
};

const NEXT_STEP: Record<string, string> = {
  NOTIFIED: "Next, it needs state and then central government approval.",
  STATE_APPROVED: "Next, it needs central government approval.",
  CENTRAL_APPROVED: "Next, the acquisition will be formally declared.",
  DECLARED: "Next, compensation will be awarded.",
  AWARDED: "Next, rehabilitation and resettlement (R&R) will begin.",
  RR_IN_PROGRESS: "Next, once R&R is complete, the government will take possession of the land.",
  POSSESSION: "Next, if a resettlement colony is involved, its infrastructure gets built out.",
  RR_COMPLETE: "This project has completed its full acquisition and resettlement process.",
};

// Minimal, typed wrapper around the browser's native Web Speech API —
// no external STT/TTS service, just what Chrome/Edge already ship.
function getSpeechRecognition(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

interface SpeechRecognitionLike extends EventTarget {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: { [key: number]: { [key: number]: { transcript: string } } } }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
}

function answerQuery(query: string, projects: PublicProject[]): string {
  const q = query.trim().toLowerCase();
  if (!q) return "You can ask me things like \"what's the status of the Sivaganga canal project?\"";

  if (/^(hi|hello|hey)\b/.test(q)) {
    return "Hello! Ask me about the status of any notified project — just say or type its name.";
  }
  if (/help|what can you|how do you work/.test(q)) {
    return "I can look up any notified project's current stage and what happens next. Try asking about a project by name, district, or purpose.";
  }

  const scored = projects
    .map((p) => {
      const haystack = `${p.name} ${p.district} ${p.state}`.toLowerCase();
      const words = q.split(/\s+/).filter((w) => w.length > 2);
      const hits = words.filter((w) => haystack.includes(w)).length;
      return { p, hits };
    })
    .filter((r) => r.hits > 0)
    .sort((a, b) => b.hits - a.hits);

  if (scored.length === 0) {
    return "I couldn't find a notified project matching that. Try the project's name or its district.";
  }
  const { p } = scored[0];
  const stageText = STAGE_LABELS[p.stage] ?? p.stage;
  const nextStep = NEXT_STEP[p.stage] ?? "";
  return `${p.name} (${p.district}, ${p.state}) is currently ${stageText}. ${nextStep}`;
}

export function VoiceChatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "bot",
      text: "Hi — I can check any notified project's status by voice or text. Ask me about a project.",
    },
  ]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [projects, setProjects] = useState<PublicProject[]>([]);
  const voiceSupported = typeof window !== "undefined" && getSpeechRecognition() !== null;
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    if (!open || projects.length > 0) return;
    fetch("/api/public/projects")
      .then((res) => res.json())
      .then((data: { projects: PublicProject[] }) => setProjects(data.projects ?? []))
      .catch(() => setProjects([]));
  }, [open, projects.length]);

  function send(text: string) {
    if (!text.trim()) return;
    setMessages((prev) => [...prev, { role: "user", text }]);
    const answer = answerQuery(text, projects);
    setMessages((prev) => [...prev, { role: "bot", text: answer }]);
    speak(answer);
    setInput("");
  }

  function startListening() {
    const SpeechRecognitionCtor = getSpeechRecognition();
    if (!SpeechRecognitionCtor) return;
    const recognition = new SpeechRecognitionCtor();
    recognition.lang = "en-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      send(transcript);
    };
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  }

  function stopListening() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-brand text-white shadow-lg transition-transform hover:scale-105"
        aria-label="Open status assistant"
      >
        <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6">
          <path
            d="M8 10.5h8M8 14h5M21 12c0 4.694-4.03 8.5-9 8.5a9.9 9.9 0 0 1-3.3-.56L3 21l1.2-3.6A8.35 8.35 0 0 1 3 12c0-4.694 4.03-8.5 9-8.5s9 3.806 9 8.5Z"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
    );
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 flex h-[28rem] w-80 flex-col overflow-hidden rounded-xl border bg-background shadow-2xl">
      <div className="flex items-center justify-between border-b bg-primary px-4 py-3 text-primary-foreground">
        <p className="text-sm font-semibold">Status Assistant</p>
        <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="text-lg leading-none">
          ×
        </button>
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto p-3">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
              m.role === "bot"
                ? "bg-secondary text-secondary-foreground"
                : "ml-auto bg-brand text-white"
            }`}
          >
            {m.text}
          </div>
        ))}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="flex items-center gap-2 border-t p-2"
      >
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about a project…"
          className="h-9 flex-1 text-sm"
        />
        {voiceSupported && (
          <Button
            type="button"
            size="icon"
            variant={listening ? "default" : "outline"}
            className="h-9 w-9 shrink-0"
            onClick={listening ? stopListening : startListening}
            aria-label={listening ? "Stop listening" : "Ask by voice"}
          >
            🎤
          </Button>
        )}
        <Button type="submit" size="sm" className="shrink-0">
          Send
        </Button>
      </form>
    </div>
  );
}
