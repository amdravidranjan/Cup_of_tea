import Link from "next/link";
import { Button } from "@/components/ui/button";
import { VoiceChatbot } from "@/components/voice-chatbot";
import { BrandLogo } from "@/components/brand-logo";
import { FileText, Send, LogIn } from "lucide-react";

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-2 border-brand bg-primary px-6 py-4 text-primary-foreground">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo className="h-9 w-9 shrink-0 text-brand" />
            <div>
              <p className="text-[11px] font-semibold tracking-[0.18em] text-primary-foreground/60 uppercase">
                Public Transparency Portal
              </p>
              <h1 className="font-heading text-[17px] font-semibold">
                National Land Acquisition &amp; Management System
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2 text-foreground">
            <Button variant="outline" asChild>
              <Link href="/request-project">
                <Send className="size-4" />
                Request a Project
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/track">
                <FileText className="size-4" />
                Track a Grievance
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/app">
                <LogIn className="size-4" />
                Government Login
              </Link>
            </Button>
          </div>
        </div>
      </header>
      <div className="border-b bg-secondary/60 px-6 py-8">
        <p className="font-heading max-w-2xl text-[19px] leading-snug text-foreground">
          Every notified land acquisition project, its statutory notices, and its
          compensation record — open to the public it affects.
        </p>
      </div>
      <main
        className="relative p-6"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140' viewBox='0 0 140 140'%3E%3Cg fill='none' stroke='%2316294d' stroke-width='1' opacity='0.045' stroke-linecap='round'%3E%3Cpath d='M10 30 Q 30 10 55 25 T 100 20'/%3E%3Cpath d='M5 80 Q 40 60 70 85 T 135 75'/%3E%3Ccircle cx='118' cy='30' r='3'/%3E%3Ccircle cx='25' cy='110' r='2.5'/%3E%3Cpath d='M90 115 l8 8 M98 115 l-8 8'/%3E%3C/g%3E%3C/svg%3E\")",
          backgroundRepeat: "repeat",
        }}
      >
        {children}
      </main>
      <VoiceChatbot />
    </div>
  );
}
