import { TrackGrievance } from "@/components/track-grievance";
import { TrackProjectRequest } from "@/components/track-project-request";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function TrackPage() {
  return (
    <div className="mx-auto max-w-lg space-y-6">
      <div>
        <p className="text-[11px] font-semibold tracking-[0.18em] text-brand uppercase">
          Public Portal
        </p>
        <h2 className="font-heading text-xl font-semibold text-foreground">Track a Submission</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Enter the tracking number you received when filing a grievance or requesting a project.
        </p>
      </div>
      <Tabs defaultValue="grievance">
        <TabsList>
          <TabsTrigger value="grievance">Grievance</TabsTrigger>
          <TabsTrigger value="request">Project Request</TabsTrigger>
        </TabsList>
        <TabsContent value="grievance" className="pt-4">
          <TrackGrievance />
        </TabsContent>
        <TabsContent value="request" className="pt-4">
          <TrackProjectRequest />
        </TabsContent>
      </Tabs>
    </div>
  );
}
