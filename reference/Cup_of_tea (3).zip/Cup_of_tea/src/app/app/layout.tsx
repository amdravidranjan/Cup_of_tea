import Link from "next/link";
import { getSession } from "@/lib/auth";
import { can } from "@/lib/rbac";
import { RoleSwitcher } from "@/components/role-switcher";
import { LogoutButton } from "@/components/logout-button";
import { NotificationBell } from "@/components/notification-bell";
import { GlobalSearch } from "@/components/global-search";
import { MoreNavMenu } from "@/components/more-nav-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, MapPinned } from "lucide-react";
import { MessageSquareWarning } from "lucide-react";

function initials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();

  const moreItems = session
    ? [
        can(session.role, "project-request:review")
          ? { href: "/app/project-requests", label: "Project Requests" }
          : null,
        can(session.role, "tender:manage")
          ? { href: "/app/contractors", label: "Contractors" }
          : null,
        can(session.role, "project:view:all")
          ? { href: "/app/reports", label: "Reports" }
          : null,
        can(session.role, "project:view:all")
          ? { href: "/app/workload", label: "District Workload" }
          : null,
        can(session.role, "conflict:review")
          ? { href: "/app/conflicts", label: "Title-Chain Conflicts" }
          : null,
        can(session.role, "encroachment:review")
          ? { href: "/app/encroachment", label: "Encroachment Monitoring" }
          : null,
        can(session.role, "land-bank:manage")
          ? { href: "/app/land-bank", label: "Land Bank" }
          : null,
        { href: "/app/interoperability", label: "Interoperability" },
        { href: "/developers", label: "Developer API" },
      ].filter((x): x is { href: string; label: string } => x !== null)
    : [];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-2 border-brand bg-primary px-6 py-4 text-primary-foreground">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold tracking-[0.18em] text-primary-foreground/60 uppercase">
              Department of Land Resources
            </p>
            <Link href="/app" className="font-heading text-lg font-semibold hover:underline">
              National Land Acquisition &amp; Management System
            </Link>
            {session && (
              <div className="mt-1.5 flex items-center gap-2">
                <Avatar className="h-6 w-6 ring-1 ring-primary-foreground/30">
                  <AvatarFallback className="bg-primary-foreground/10 text-[10px] text-primary-foreground">
                    {initials(session.name)}
                  </AvatarFallback>
                </Avatar>
                <p className="text-sm text-primary-foreground/75">
                  {session.name} &middot; {session.role}
                </p>
              </div>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-foreground">
            {session && <GlobalSearch />}
            {session && (
              <Button variant="outline" asChild>
                <Link href="/app">
                  <LayoutDashboard className="size-4" />
                  Dashboard
                </Link>
              </Button>
            )}
            {session && can(session.role, "parcel:update-status") && (
              <Button variant="outline" asChild>
                <Link href="/app/field">
                  <MapPinned className="size-4" />
                  Field Verification
                </Link>
              </Button>
            )}
            {session && can(session.role, "grievance:manage") && (
              <Button variant="outline" asChild>
                <Link href="/app/grievances">
                  <MessageSquareWarning className="size-4" />
                  Grievances
                </Link>
              </Button>
            )}
            {session && <MoreNavMenu items={moreItems} />}
            {session && <NotificationBell />}
            <RoleSwitcher />
            {session && <LogoutButton />}
          </div>
        </div>
      </header>
      <main className="p-6">
        {session ? (
          children
        ) : (
          <p className="text-sm text-muted-foreground">
            Select a demo role above to continue.
          </p>
        )}
      </main>
    </div>
  );
}
